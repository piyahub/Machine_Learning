a = [3, 4, 5];
b = [7, 8, 9];

dot_product = dot(a, b);

cross_product = cross(a, b);

disp('The dot product of the vectors is:');
disp(dot_product);

disp('The cross product of the vectors is:');
disp(cross_product);
