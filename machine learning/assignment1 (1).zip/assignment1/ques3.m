
n = input('Enter the value of n: ');
roll_number = 22126053;
A = zeros(n);
A(1, :) = roll_number;
A(2:end, :) = randi(100, n-1, n);
disp(A);
