

% 10.1) Import the color image and reduce the size to half

% Step 1: Import the color image
img = imread('photo.jpg');

% Step 2: Display and save the original image (fig1)
figure;
imshow(img);
title('Original Image');
saveas(gcf, 'fig1.jpg'); 

% Step 3: Reduce the size of the image to half (fig2)
img_resized = imresize(img, 0.5);

% Step 4: Display and save the resized image (fig2)
figure;
imshow(img_resized);
title('Resized Image to Half');
saveas(gcf, 'fig2.jpg'); 

% 10.2) Convert the color image into grayscale image (fig3)

% Step 5: Convert the resized color image to grayscale
img_gray = rgb2gray(img_resized);

% Step 6: Display and save the grayscale image (fig3)
figure;
imshow(img_gray);
title('Grayscale Image');
saveas(gcf, 'fig3.jpg'); 

% 10.3) Convert the grayscale image into a 1D array of pixels

% Step 7: Convert the grayscale image to a 1D array of pixels
img_gray_1D = img_gray(:);

% 10.4) Using the 1D array obtain the grayscale image (fig4)

% Step 8: Convert the 1D array back to the original 2D grayscale image (fig4)
img_gray_restored = reshape(img_gray_1D, size(img_gray));

% Step 9: Display and save the restored grayscale image (fig4)
figure;
imshow(img_gray_restored);
title('Restored Grayscale Image from 1D Array');
saveas(gcf, 'fig4.jpg'); % Save the figure as fig4.png

% 10.5) Convert the grayscale image back to a color image (fig5)
% Create an artificial colorization by modifying the grayscale image

% Example 1: Apply a color map to the grayscale image (e.g., 'jet' colormap)
img_color_restored = ind2rgb(im2uint8(mat2gray(img_gray_restored)), jet(256));



% Step 11: Display and save the artificially colorized image (fig5)
figure;
imshow(img_color_restored);
title('Artificially Colorized Image from Grayscale');
saveas(gcf, 'fig5.jpg'); % Save the figure as fig5.png
