R = 53;
M = 1;
W = 6;  
coefficients = [R, R*M, W, 25];
roots_of_polynomial = roots(coefficients);
disp('The roots of the polynomial are:');
disp(roots_of_polynomial);
